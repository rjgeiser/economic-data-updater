# Economic Data Updater

Automates economic data collection into Google Sheets.